Third party libraries sources:
  GeoTools  http://geotools.codehaus.org/